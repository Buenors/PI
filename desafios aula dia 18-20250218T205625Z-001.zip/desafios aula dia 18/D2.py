a = int(input("inteiro "))
import operações as op
print(f'Antecessor: {op.sub(a,1)} \nSucessor: {op.soma(a,1)}')