a = float(input("Medida em metros "))
import operações as op

print(f'Centímetros: {op.cm(a)} \nMilímetros: {op.mm(a)}')