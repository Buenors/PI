a = float(input("Número "))
import operações as op
print(f'Dobro: {op.mult(a,2)} \nTriplo: {op.mult(a,3)} \nRaiz: {op.pot(a,1/2)}')