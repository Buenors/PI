a = float(input("Preço "))
b = int(input("Desconto "))
import operações as op
print(f'Preço com desconto de {b}% é igual a {op.desc(a,b)}')