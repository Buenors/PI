a = float(input("Nota 1 "))
b = float(input("Nota 2 "))
import operações as op
print(f'Média: {op.med(a,b)}')