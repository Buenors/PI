a = int(input("Número "))
b = int(input("Tabuada "))
import operações as op
i = 0
while i <= b:
     t = a * i 
     print(f'{a}*{i}: {t}')
     i += 1
